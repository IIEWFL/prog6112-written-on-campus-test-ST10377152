/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package roadaccidentreport;

import java.util.Scanner;

public class RoadAccidentReport {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        
       
        int[][] collisions = new int[3][2];
        
       
        for (int i = 0; i < cities.length; i++) {
            System.out.print("Enter the number of car accidents for " + cities[i] + ": ");
            collisions[i][0] = scanner.nextInt();
            
            System.out.print("Enter the number of motorbike accidents for " + cities[i] + ": ");
            collisions[i][1] = scanner.nextInt();
        }
        
        System.out.println("-----------------------------------------------------");
        System.out.println("ROAD ACCIDENT REPORT");
        System.out.println("-----------------------------------------------------");
        System.out.printf("%-20s %-10s %-10s\n", "City", "CAR", "MOTOR BIKE");
        
        
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-20s %-10d %-10d\n", cities[i], collisions[i][0], collisions[i][1]);
        }
        
        
        int[] totalAccidentsPerCity = new int[3];
        int maxAccidents = 0;
        String cityWithMostAccidents = "";
        
        System.out.println("----------------------------------------------------");
        System.out.println("ROAD ACCIDENT TOTALS FOR EACH CITY");
        System.out.println("----------------------------------------------------");
        for (int i = 0; i < cities.length; i++) {
            totalAccidentsPerCity[i] = collisions[i][0] + collisions[i][1];
            System.out.printf("%-20s %-10d\n", cities[i], totalAccidentsPerCity[i]);
            
            if (totalAccidentsPerCity[i] > maxAccidents) {
                maxAccidents = totalAccidentsPerCity[i];
                cityWithMostAccidents = cities[i];
            }
        }
        
        
        System.out.println("\nCITY WITH THE MOST VEHICLE ACCIDENTS: " + cityWithMostAccidents);
        System.out.println("-----------------------------------------------------");
        
        scanner.close();
    }
}
