/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package roadreport;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class RoadReport {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter the accident vehicle type: ");
        String vehicleType = scanner.nextLine();

       
        System.out.print("Enter the city for the vehicle accidents: ");
        String city = scanner.nextLine();

       
        System.out.print("Enter the total " + vehicleType + " accidents for " + city + ": ");
        int totalAccidents = scanner.nextInt();

        
        RoadAccidentReport report = new RoadAccidentReport(vehicleType, city, totalAccidents) {
            @Override
            public String getcity() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };

        
        report.printAccidentReport();
    }
}
